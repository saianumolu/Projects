include weka.jar file in the source

How to Compile the code :   javac	DMProject3.java

How to Run the code:          java		DMProject3	 WholesaleCustomersDataUCI.csv	3	2	2
