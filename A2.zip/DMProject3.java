package weka.api;
import java.io.*;
import java.util.Random;
import weka.core.Instance;
import weka.core.Instances;
import weka.clusterers.SimpleKMeans;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Discretize;
import weka.core.converters.ArffSaver;
import weka.core.converters.ConverterUtils.DataSource;
import weka.associations.Apriori;
import weka.filters.unsupervised.attribute.NumericToNominal;

public class DMProject3{
	
	public static void main(String []args) throws Exception{
		DataSource datavalue=new DataSource(args[0]);
		Instances data=datavalue.getDataSet();
		int attr=data.numAttributes();
		SimpleKMeans kmeancluster= new SimpleKMeans();/*clustering using k-means*/
		kmeancluster.setPreserveInstancesOrder(true);
		int numclusters=Integer.parseInt(args[1]);/* taking the value of K from argument */
		kmeancluster.setNumClusters(numclusters);
		kmeancluster.buildClusterer(data);
		double Evalue=kmeancluster.getSquaredError();
		int[] assign=kmeancluster.getAssignments();
		Discretize filter=new Discretize();
		/*binning the data*/
		filter.setInputFormat(data);
		int numofbins=Integer.parseInt(args[2]);
		/*taking the number of bins from the command line arguments*/
		int numofpatterns = Integer.parseInt(args[3]);
		/*number of patterns 'p' is taken from command line arguments*/
		filter.setBins(numofbins);
		Filter.useFilter(data,filter);
		int lenthofdata=data.numInstances();
	
				String[] options = new String[4];
		
				options[0] = "-B";
				options[1] = args[2].trim();
				
				options[2] = "-R";
				options[3] = "first-last";
			
				Discretize discretize = new Discretize();
				discretize.setOptions(options);
				discretize.setInputFormat(data);
				Instances newData = Filter.useFilter(data, discretize);
				
				ArffSaver saver = new ArffSaver();
				saver.setInstances(newData);
				saver.setFile(new File("bins.txt"));
				/*This is the output of bins where the value of 'b' is from arguments*/
				saver.writeBatch();
		BufferedWriter write1=new BufferedWriter(new FileWriter(new File("binningMap.txt")));
		/*binmapping text file*/
		write1.write("Mapping According to BIN count \n");
		for(int i=0;i<lenthofdata;i++)
		{
			Instance inst=data.get(i);
			for(int k=0;k<attr;k++){
			double[] cutvalue=filter.getCutPoints(k);
			double[] noofcuts=new double[numofbins+1];
			noofcuts[0]=-100000000.0;
			noofcuts[numofbins]=100000000.0;
			write1.write("Attribute "+Integer.toString(k+1)+"\n");
			/* here for each attribute based on bin number , bins are divided*/
			for(int m=1;m<numofbins;m++)
			{
				noofcuts[m]=cutvalue[m-1];
			}
			for(int j=0;j<numofbins;j++)
			{
				write1.write("[ "+Double.toString(noofcuts[j])+","+Double.toString(noofcuts[j+1])+" ]---->"+Integer.toString((k+1)*numofbins+j)+"\n");
			}
			for(int j=0;j<numofbins+1;j++)
			{
				if(inst.value(k)>noofcuts[j] && inst.value(k)<=noofcuts[j+1])
				{
					inst.setValue(k,(k+1)*numofbins+j);
				}
			}
		}
		}
		write1.close();

		NumericToNominal NtN=new NumericToNominal();/* changing the value to nominal */
		NtN.setInputFormat(data);
		Instances newvalue=Filter.useFilter(data,NtN);
		Apriori nopatterns= new Apriori();/* using APRIORI function for setof rules*/
		nopatterns.setNumRules(1000);
		
		nopatterns.buildAssociations(newvalue);
		String rules=nopatterns.toString();
		int [][] points=getassorules(rules,attr);
		
		double [][] supports= findsupports(data,assign,points,numclusters);
		BufferedWriter writ=new BufferedWriter(new FileWriter(new File("selectedPatterns.csv")));
		System.out.println("Output files are downloaded");
		/*set of patterns selected is saved in .csv file*/
		writ.write("Patterns Selected\n");
		double[][] errors=new double[numclusters][2];
		for(int i=0;i<numclusters;i++)
		{
			double a,b;
			a=0.0;
			b=0.0;
			Random randomval = new Random();
			for(int j=0;j<numofpatterns;j++)
			{
				int n= randomval.nextInt(1000);
				double [] supp= supports[n];
				int [] assorules= points[n];
				writ.write("{");
				for(int k=0;k<assorules.length;k++)
				{
					if(assorules[k]!=0)
					{
						writ.write(Integer.toString(assorules[k])+":");
					}
				}
				writ.write("}, ");
				for(int k=0;k<numclusters;k++)
				{
					if(k==i)
					{
						a+=supp[k];
						writ.write(Double.toString(supp[k])+",");
					}
					else
					{
						b+=supp[k]*.2;
						writ.write(Double.toString(supp[k]*.2)+",");
					}
				}
				writ.write("\n");
			}
			errors[i][0]=a/numclusters;
			errors[i][1]=(1-(b/numclusters));
		}
		writ.write("E-value--->");
		writ.write(Double.toString(Evalue));
		writ.write("\n");
		double avg1,avg2;
		avg1=0.0;
		avg2=0.0;
		for(int i=0;i<numclusters;i++)
		{
			avg1+=(1/errors[i][0]);
			avg2+=(1/errors[i][1]);
		}
		writ.write(" Avg HomeCluster Harmonic mean s-->");
		writ.write(Double.toString(numclusters/avg1));
		writ.write("\n");
		writ.write("1-AvgForeignClusterSupport Harmonic mean --> ");
		writ.write(Double.toString(numclusters/avg2));
		writ.write("\n");	
		writ.close();

		
	}
	public static int[][] getassorules(String rules,int attr)
	{
		String[] d=rules.split("Best rules found:");
		String[] rules1=d[1].split("\n");
		int[][] points=new int[1000][attr];
		
		
		for(int k=2;k<1002;k++)
		{ 
			int n=0;
			
			for(int i=0;i<(rules1[k].length())-1;i++)
			{
				if(rules1[k].charAt(i)=='=' && rules1[k].charAt(i+1)!='='&& rules1[k].charAt(i+1)!='>')
				{
					try{
						points[k-2][n]=Integer.parseInt(rules1[k].substring(i+1,i+3));
						n=n+1;
					}
						catch(NumberFormatException ex){ // handle your exception
					}
				}
			}
		}
		
		
		return points;

	}
	public static int[][] toarray(Instances data,int[] assign,int val,int attr)
	{
		int len=0;
		for(int a:assign)
		{
			if(a==val)
			{
				len+=1;
			}
		}
		int[][] newvalue=new int[len][attr];
		int index=0;
		for(int i=0;i<data.numInstances();i++)
		{
			if(assign[i]==val)
			{
				double[] arr=data.get(i).toDoubleArray();
				for(int j=0;j<attr;j++)
				{
					newvalue[index][j]=(int)arr[j];
				}
				index+=1;
			}
		}
		return newvalue;
	}
	public static double findsupport(int[][] data, int[] assorules)
	{
		int len=0;
		for(int i=0;i<assorules.length;i++)
		{
			if(assorules[i]!=0)
			{
				len+=1;
			}
		}
		double val=0.0;
		for(int i=0;i<data.length;i++)
		{
			if(compare(data[i],assorules)==len)
			{
				val=val+1;
			}
		}
		return val/(double)data.length;
	}
	public static int compare(int[] arr1,int[] arr2)
	{
		int a=0;
		for(int i=0;i<arr2.length;i++)
		{
			if(arr2[i]!=0)
			{
				for(int j=0;j<arr1.length;j++)
				{
					if(arr2[i]==arr1[j])
					{
						a=a+1;
					}
				}
			}
		}
		return a;
	}
	public static double [][] findsupports(Instances data,int[] assign,int[][] rules,int numclusters)
	{
		double [][] supports=new double[1000][numclusters];
		for(int i=0;i<numclusters;i++)
		{
			int[][] custerdata=toarray(data,assign,i,data.numAttributes());
			for(int j=0;j<1000;j++)
			{
				supports[j][i]=findsupport(custerdata,rules[j]);
			}
		}
		return supports;
	}
}